#ifndef _COMUM_H_
#define _COMUM_H_

#define ERR_ARGS 1

/*
 * definicoes, estruturas comuns ao cliente e ao servidor
 */

#endif
